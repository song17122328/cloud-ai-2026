#!/bin/bash
# 在 π2.0 登录节点运行一次，约 5–10 分钟：bash setup_env.sh
# 建立 ~/envs/fedlora 环境。版本已在课程测试中验证，请勿自行升级。
set -e
module load miniconda3/24.3.0
conda create -y -q -p ~/envs/fedlora python=3.11
PIP=~/envs/fedlora/bin/pip
MIRROR=https://mirror.sjtu.edu.cn/pypi/web/simple
$PIP install -q torch==2.5.1 --index-url https://download.pytorch.org/whl/cu121
$PIP install -q -i $MIRROR "transformers==4.46.3" "peft==0.13.2" accelerate pandas scikit-learn matplotlib \
    "numpy<2" "pyarrow<18" huggingface_hub
~/envs/fedlora/bin/python -c "import torch, transformers, peft, pyarrow; print('ok', torch.__version__, transformers.__version__, peft.__version__)"
