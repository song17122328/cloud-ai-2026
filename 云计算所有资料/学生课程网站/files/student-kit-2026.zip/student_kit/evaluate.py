"""课程统一评测脚本。助教用同一脚本评测全部提交，请先用它自查适配器能否正常加载。

适配器要求：Qwen2.5-1.5B-Instruct 的 AutoModelForSequenceClassification（num_labels=77）
加 LoRA 后，用 PEFT 的 save_pretrained 保存，目录内含 adapter_config.json 与权重文件。
分类头 score 需随适配器一起保存（task_type=SEQ_CLS 时 PEFT 会自动保存）。

用法（在计算节点运行）：
  python evaluate.py --adapter runs/xxx/final_adapter --split val
"""
import argparse
import json

import numpy as np
import pandas as pd
import torch
from peft import PeftModel
from sklearn.metrics import accuracy_score, f1_score
from transformers import AutoModelForSequenceClassification, AutoTokenizer


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="models/Qwen2.5-1.5B-Instruct")
    ap.add_argument("--adapter", required=True)
    ap.add_argument("--data", default="data/banking77")
    ap.add_argument("--split_file", default="splits/split.json")
    ap.add_argument("--split", default="val", choices=["val", "test"])
    a = ap.parse_args()

    if a.split == "val":
        df = pd.read_parquet(f"{a.data}/train.parquet")
        df = df.iloc[json.load(open(a.split_file))["val"]]
    else:
        df = pd.read_parquet(f"{a.data}/test.parquet")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    tok = AutoTokenizer.from_pretrained(a.model)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    base = AutoModelForSequenceClassification.from_pretrained(a.model, num_labels=77)
    base.config.pad_token_id = tok.pad_token_id
    model = PeftModel.from_pretrained(base, a.adapter).to(device).eval()

    preds = []
    texts = df["text"].tolist()
    with torch.no_grad():
        for i in range(0, len(texts), 64):
            enc = tok(texts[i:i + 64], padding=True, truncation=True, max_length=64, return_tensors="pt").to(device)
            with torch.autocast(device.type, dtype=torch.float16, enabled=device.type == "cuda"):
                preds += model(**enc).logits.argmax(-1).cpu().tolist()
    gold = df["label"].tolist()
    print(json.dumps({"adapter": a.adapter, "split": a.split, "n": len(gold),
                      "acc": round(accuracy_score(gold, preds), 4),
                      "macro_f1": round(f1_score(gold, preds, average="macro"), 4)}))


if __name__ == "__main__":
    main()
