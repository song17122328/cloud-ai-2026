#!/bin/bash
# 在思源一号登录节点（sylogin）运行一次，约 15 分钟：bash setup_env_sy.sh
# 与 setup_env.sh 相同，只是 PyTorch 改从交大镜像安装（思源一号连接 PyTorch 官方源会超时）。
set -e
module load miniconda3/24.3.0
conda create -y -q -p ~/envs/fedlora python=3.11
PIP=~/envs/fedlora/bin/pip
MIRROR=https://mirror.sjtu.edu.cn/pypi/web/simple
$PIP install -q -i $MIRROR torch==2.5.1
$PIP install -q -i $MIRROR "transformers==4.46.3" "peft==0.13.2" accelerate pandas scikit-learn matplotlib \
    "numpy<2" "pyarrow<18" huggingface_hub
~/envs/fedlora/bin/python -c "import torch, transformers, peft, pyarrow; print('ok', torch.__version__, transformers.__version__, peft.__version__)"
